/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Computer_Organization/P6/CPU_decoder/D.v";
static int ng1[] = {1, 0};
static int ng2[] = {0, 0};



static void Cont_88_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t20[8];
    char t35[8];
    char t43[8];
    char t91[8];
    char t92[8];
    char t95[8];
    char t109[8];
    char t124[8];
    char t132[8];
    char t180[8];
    char t181[8];
    char t184[8];
    char t198[8];
    char t199[8];
    char t207[8];
    char t255[8];
    char t256[8];
    char t259[8];
    char t273[8];
    char t274[8];
    char t282[8];
    char t330[8];
    char t331[8];
    char t334[8];
    char t348[8];
    char t349[8];
    char t357[8];
    char t405[8];
    char t406[8];
    char t409[8];
    char t423[8];
    char t424[8];
    char t432[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    int t67;
    int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t93;
    char *t94;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    char *t108;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    char *t123;
    char *t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    char *t131;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    char *t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    char *t146;
    char *t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    int t156;
    int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    char *t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    char *t170;
    char *t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    char *t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    char *t182;
    char *t183;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    char *t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    char *t196;
    char *t197;
    char *t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    char *t206;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    char *t211;
    char *t212;
    char *t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    char *t221;
    char *t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    unsigned int t229;
    unsigned int t230;
    int t231;
    int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    char *t239;
    unsigned int t240;
    unsigned int t241;
    unsigned int t242;
    unsigned int t243;
    unsigned int t244;
    char *t245;
    char *t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    char *t250;
    unsigned int t251;
    unsigned int t252;
    unsigned int t253;
    unsigned int t254;
    char *t257;
    char *t258;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    char *t265;
    char *t266;
    unsigned int t267;
    unsigned int t268;
    unsigned int t269;
    char *t271;
    char *t272;
    char *t275;
    unsigned int t276;
    unsigned int t277;
    unsigned int t278;
    unsigned int t279;
    unsigned int t280;
    char *t281;
    unsigned int t283;
    unsigned int t284;
    unsigned int t285;
    char *t286;
    char *t287;
    char *t288;
    unsigned int t289;
    unsigned int t290;
    unsigned int t291;
    unsigned int t292;
    unsigned int t293;
    unsigned int t294;
    unsigned int t295;
    char *t296;
    char *t297;
    unsigned int t298;
    unsigned int t299;
    unsigned int t300;
    unsigned int t301;
    unsigned int t302;
    unsigned int t303;
    unsigned int t304;
    unsigned int t305;
    int t306;
    int t307;
    unsigned int t308;
    unsigned int t309;
    unsigned int t310;
    unsigned int t311;
    unsigned int t312;
    unsigned int t313;
    char *t314;
    unsigned int t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t319;
    char *t320;
    char *t321;
    unsigned int t322;
    unsigned int t323;
    unsigned int t324;
    char *t325;
    unsigned int t326;
    unsigned int t327;
    unsigned int t328;
    unsigned int t329;
    char *t332;
    char *t333;
    unsigned int t335;
    unsigned int t336;
    unsigned int t337;
    unsigned int t338;
    unsigned int t339;
    char *t340;
    char *t341;
    unsigned int t342;
    unsigned int t343;
    unsigned int t344;
    char *t346;
    char *t347;
    char *t350;
    unsigned int t351;
    unsigned int t352;
    unsigned int t353;
    unsigned int t354;
    unsigned int t355;
    char *t356;
    unsigned int t358;
    unsigned int t359;
    unsigned int t360;
    char *t361;
    char *t362;
    char *t363;
    unsigned int t364;
    unsigned int t365;
    unsigned int t366;
    unsigned int t367;
    unsigned int t368;
    unsigned int t369;
    unsigned int t370;
    char *t371;
    char *t372;
    unsigned int t373;
    unsigned int t374;
    unsigned int t375;
    unsigned int t376;
    unsigned int t377;
    unsigned int t378;
    unsigned int t379;
    unsigned int t380;
    int t381;
    int t382;
    unsigned int t383;
    unsigned int t384;
    unsigned int t385;
    unsigned int t386;
    unsigned int t387;
    unsigned int t388;
    char *t389;
    unsigned int t390;
    unsigned int t391;
    unsigned int t392;
    unsigned int t393;
    unsigned int t394;
    char *t395;
    char *t396;
    unsigned int t397;
    unsigned int t398;
    unsigned int t399;
    char *t400;
    unsigned int t401;
    unsigned int t402;
    unsigned int t403;
    unsigned int t404;
    char *t407;
    char *t408;
    unsigned int t410;
    unsigned int t411;
    unsigned int t412;
    unsigned int t413;
    unsigned int t414;
    char *t415;
    char *t416;
    unsigned int t417;
    unsigned int t418;
    unsigned int t419;
    char *t421;
    char *t422;
    char *t425;
    unsigned int t426;
    unsigned int t427;
    unsigned int t428;
    unsigned int t429;
    unsigned int t430;
    char *t431;
    unsigned int t433;
    unsigned int t434;
    unsigned int t435;
    char *t436;
    char *t437;
    char *t438;
    unsigned int t439;
    unsigned int t440;
    unsigned int t441;
    unsigned int t442;
    unsigned int t443;
    unsigned int t444;
    unsigned int t445;
    char *t446;
    char *t447;
    unsigned int t448;
    unsigned int t449;
    unsigned int t450;
    unsigned int t451;
    unsigned int t452;
    unsigned int t453;
    unsigned int t454;
    unsigned int t455;
    int t456;
    int t457;
    unsigned int t458;
    unsigned int t459;
    unsigned int t460;
    unsigned int t461;
    unsigned int t462;
    unsigned int t463;
    char *t464;
    unsigned int t465;
    unsigned int t466;
    unsigned int t467;
    unsigned int t468;
    unsigned int t469;
    char *t470;
    char *t471;
    unsigned int t472;
    unsigned int t473;
    unsigned int t474;
    char *t475;
    unsigned int t476;
    unsigned int t477;
    unsigned int t478;
    unsigned int t479;
    char *t480;
    char *t481;
    char *t482;
    char *t483;
    char *t484;
    char *t485;
    unsigned int t486;
    unsigned int t487;
    char *t488;
    unsigned int t489;
    unsigned int t490;
    char *t491;
    unsigned int t492;
    unsigned int t493;
    char *t494;

LAB0:    t1 = (t0 + 3648U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(88, ng0);
    t2 = (t0 + 1688U);
    t5 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t5 + 4);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t13 = (t6 + 4);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t13);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB8;

LAB9:    memcpy(t43, t6, 8);

LAB10:    memset(t4, 0, 8);
    t75 = (t43 + 4);
    t76 = *((unsigned int *)t75);
    t77 = (~(t76));
    t78 = *((unsigned int *)t43);
    t79 = (t78 & t77);
    t80 = (t79 & 1U);
    if (t80 != 0)
        goto LAB22;

LAB23:    if (*((unsigned int *)t75) != 0)
        goto LAB24;

LAB25:    t82 = (t4 + 4);
    t83 = *((unsigned int *)t4);
    t84 = *((unsigned int *)t82);
    t85 = (t83 || t84);
    if (t85 > 0)
        goto LAB26;

LAB27:    t87 = *((unsigned int *)t4);
    t88 = (~(t87));
    t89 = *((unsigned int *)t82);
    t90 = (t88 || t89);
    if (t90 > 0)
        goto LAB28;

LAB29:    if (*((unsigned int *)t82) > 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t4) > 0)
        goto LAB32;

LAB33:    memcpy(t3, t91, 8);

LAB34:    t481 = (t0 + 4048);
    t482 = (t481 + 56U);
    t483 = *((char **)t482);
    t484 = (t483 + 56U);
    t485 = *((char **)t484);
    memset(t485, 0, 8);
    t486 = 1U;
    t487 = t486;
    t488 = (t3 + 4);
    t489 = *((unsigned int *)t3);
    t486 = (t486 & t489);
    t490 = *((unsigned int *)t488);
    t487 = (t487 & t490);
    t491 = (t485 + 4);
    t492 = *((unsigned int *)t485);
    *((unsigned int *)t485) = (t492 | t486);
    t493 = *((unsigned int *)t491);
    *((unsigned int *)t491) = (t493 | t487);
    xsi_driver_vfirst_trans(t481, 0, 0);
    t494 = (t0 + 3968);
    *((int *)t494) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t6) = 1;
    goto LAB7;

LAB6:    t12 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB7;

LAB8:    t17 = (t0 + 1208U);
    t18 = *((char **)t17);
    t17 = (t0 + 1368U);
    t19 = *((char **)t17);
    memset(t20, 0, 8);
    t17 = (t18 + 4);
    t21 = (t19 + 4);
    t22 = *((unsigned int *)t18);
    t23 = *((unsigned int *)t19);
    t24 = (t22 ^ t23);
    t25 = *((unsigned int *)t17);
    t26 = *((unsigned int *)t21);
    t27 = (t25 ^ t26);
    t28 = (t24 | t27);
    t29 = *((unsigned int *)t17);
    t30 = *((unsigned int *)t21);
    t31 = (t29 | t30);
    t32 = (~(t31));
    t33 = (t28 & t32);
    if (t33 != 0)
        goto LAB14;

LAB11:    if (t31 != 0)
        goto LAB13;

LAB12:    *((unsigned int *)t20) = 1;

LAB14:    memset(t35, 0, 8);
    t36 = (t20 + 4);
    t37 = *((unsigned int *)t36);
    t38 = (~(t37));
    t39 = *((unsigned int *)t20);
    t40 = (t39 & t38);
    t41 = (t40 & 1U);
    if (t41 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t36) != 0)
        goto LAB17;

LAB18:    t44 = *((unsigned int *)t6);
    t45 = *((unsigned int *)t35);
    t46 = (t44 & t45);
    *((unsigned int *)t43) = t46;
    t47 = (t6 + 4);
    t48 = (t35 + 4);
    t49 = (t43 + 4);
    t50 = *((unsigned int *)t47);
    t51 = *((unsigned int *)t48);
    t52 = (t50 | t51);
    *((unsigned int *)t49) = t52;
    t53 = *((unsigned int *)t49);
    t54 = (t53 != 0);
    if (t54 == 1)
        goto LAB19;

LAB20:
LAB21:    goto LAB10;

LAB13:    t34 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t34) = 1;
    goto LAB14;

LAB15:    *((unsigned int *)t35) = 1;
    goto LAB18;

LAB17:    t42 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t42) = 1;
    goto LAB18;

LAB19:    t55 = *((unsigned int *)t43);
    t56 = *((unsigned int *)t49);
    *((unsigned int *)t43) = (t55 | t56);
    t57 = (t6 + 4);
    t58 = (t35 + 4);
    t59 = *((unsigned int *)t6);
    t60 = (~(t59));
    t61 = *((unsigned int *)t57);
    t62 = (~(t61));
    t63 = *((unsigned int *)t35);
    t64 = (~(t63));
    t65 = *((unsigned int *)t58);
    t66 = (~(t65));
    t67 = (t60 & t62);
    t68 = (t64 & t66);
    t69 = (~(t67));
    t70 = (~(t68));
    t71 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t71 & t69);
    t72 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t72 & t70);
    t73 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t73 & t69);
    t74 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t74 & t70);
    goto LAB21;

LAB22:    *((unsigned int *)t4) = 1;
    goto LAB25;

LAB24:    t81 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t81) = 1;
    goto LAB25;

LAB26:    t86 = ((char*)((ng1)));
    goto LAB27;

LAB28:    t93 = (t0 + 1848U);
    t94 = *((char **)t93);
    memset(t95, 0, 8);
    t93 = (t94 + 4);
    t96 = *((unsigned int *)t93);
    t97 = (~(t96));
    t98 = *((unsigned int *)t94);
    t99 = (t98 & t97);
    t100 = (t99 & 1U);
    if (t100 != 0)
        goto LAB35;

LAB36:    if (*((unsigned int *)t93) != 0)
        goto LAB37;

LAB38:    t102 = (t95 + 4);
    t103 = *((unsigned int *)t95);
    t104 = *((unsigned int *)t102);
    t105 = (t103 || t104);
    if (t105 > 0)
        goto LAB39;

LAB40:    memcpy(t132, t95, 8);

LAB41:    memset(t92, 0, 8);
    t164 = (t132 + 4);
    t165 = *((unsigned int *)t164);
    t166 = (~(t165));
    t167 = *((unsigned int *)t132);
    t168 = (t167 & t166);
    t169 = (t168 & 1U);
    if (t169 != 0)
        goto LAB53;

LAB54:    if (*((unsigned int *)t164) != 0)
        goto LAB55;

LAB56:    t171 = (t92 + 4);
    t172 = *((unsigned int *)t92);
    t173 = *((unsigned int *)t171);
    t174 = (t172 || t173);
    if (t174 > 0)
        goto LAB57;

LAB58:    t176 = *((unsigned int *)t92);
    t177 = (~(t176));
    t178 = *((unsigned int *)t171);
    t179 = (t177 || t178);
    if (t179 > 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t171) > 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t92) > 0)
        goto LAB63;

LAB64:    memcpy(t91, t180, 8);

LAB65:    goto LAB29;

LAB30:    xsi_vlog_unsigned_bit_combine(t3, 32, t86, 32, t91, 32);
    goto LAB34;

LAB32:    memcpy(t3, t86, 8);
    goto LAB34;

LAB35:    *((unsigned int *)t95) = 1;
    goto LAB38;

LAB37:    t101 = (t95 + 4);
    *((unsigned int *)t95) = 1;
    *((unsigned int *)t101) = 1;
    goto LAB38;

LAB39:    t106 = (t0 + 1208U);
    t107 = *((char **)t106);
    t106 = (t0 + 1368U);
    t108 = *((char **)t106);
    memset(t109, 0, 8);
    t106 = (t107 + 4);
    t110 = (t108 + 4);
    t111 = *((unsigned int *)t107);
    t112 = *((unsigned int *)t108);
    t113 = (t111 ^ t112);
    t114 = *((unsigned int *)t106);
    t115 = *((unsigned int *)t110);
    t116 = (t114 ^ t115);
    t117 = (t113 | t116);
    t118 = *((unsigned int *)t106);
    t119 = *((unsigned int *)t110);
    t120 = (t118 | t119);
    t121 = (~(t120));
    t122 = (t117 & t121);
    if (t122 != 0)
        goto LAB43;

LAB42:    if (t120 != 0)
        goto LAB44;

LAB45:    memset(t124, 0, 8);
    t125 = (t109 + 4);
    t126 = *((unsigned int *)t125);
    t127 = (~(t126));
    t128 = *((unsigned int *)t109);
    t129 = (t128 & t127);
    t130 = (t129 & 1U);
    if (t130 != 0)
        goto LAB46;

LAB47:    if (*((unsigned int *)t125) != 0)
        goto LAB48;

LAB49:    t133 = *((unsigned int *)t95);
    t134 = *((unsigned int *)t124);
    t135 = (t133 & t134);
    *((unsigned int *)t132) = t135;
    t136 = (t95 + 4);
    t137 = (t124 + 4);
    t138 = (t132 + 4);
    t139 = *((unsigned int *)t136);
    t140 = *((unsigned int *)t137);
    t141 = (t139 | t140);
    *((unsigned int *)t138) = t141;
    t142 = *((unsigned int *)t138);
    t143 = (t142 != 0);
    if (t143 == 1)
        goto LAB50;

LAB51:
LAB52:    goto LAB41;

LAB43:    *((unsigned int *)t109) = 1;
    goto LAB45;

LAB44:    t123 = (t109 + 4);
    *((unsigned int *)t109) = 1;
    *((unsigned int *)t123) = 1;
    goto LAB45;

LAB46:    *((unsigned int *)t124) = 1;
    goto LAB49;

LAB48:    t131 = (t124 + 4);
    *((unsigned int *)t124) = 1;
    *((unsigned int *)t131) = 1;
    goto LAB49;

LAB50:    t144 = *((unsigned int *)t132);
    t145 = *((unsigned int *)t138);
    *((unsigned int *)t132) = (t144 | t145);
    t146 = (t95 + 4);
    t147 = (t124 + 4);
    t148 = *((unsigned int *)t95);
    t149 = (~(t148));
    t150 = *((unsigned int *)t146);
    t151 = (~(t150));
    t152 = *((unsigned int *)t124);
    t153 = (~(t152));
    t154 = *((unsigned int *)t147);
    t155 = (~(t154));
    t156 = (t149 & t151);
    t157 = (t153 & t155);
    t158 = (~(t156));
    t159 = (~(t157));
    t160 = *((unsigned int *)t138);
    *((unsigned int *)t138) = (t160 & t158);
    t161 = *((unsigned int *)t138);
    *((unsigned int *)t138) = (t161 & t159);
    t162 = *((unsigned int *)t132);
    *((unsigned int *)t132) = (t162 & t158);
    t163 = *((unsigned int *)t132);
    *((unsigned int *)t132) = (t163 & t159);
    goto LAB52;

LAB53:    *((unsigned int *)t92) = 1;
    goto LAB56;

LAB55:    t170 = (t92 + 4);
    *((unsigned int *)t92) = 1;
    *((unsigned int *)t170) = 1;
    goto LAB56;

LAB57:    t175 = ((char*)((ng1)));
    goto LAB58;

LAB59:    t182 = (t0 + 2008U);
    t183 = *((char **)t182);
    memset(t184, 0, 8);
    t182 = (t183 + 4);
    t185 = *((unsigned int *)t182);
    t186 = (~(t185));
    t187 = *((unsigned int *)t183);
    t188 = (t187 & t186);
    t189 = (t188 & 1U);
    if (t189 != 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t182) != 0)
        goto LAB68;

LAB69:    t191 = (t184 + 4);
    t192 = *((unsigned int *)t184);
    t193 = *((unsigned int *)t191);
    t194 = (t192 || t193);
    if (t194 > 0)
        goto LAB70;

LAB71:    memcpy(t207, t184, 8);

LAB72:    memset(t181, 0, 8);
    t239 = (t207 + 4);
    t240 = *((unsigned int *)t239);
    t241 = (~(t240));
    t242 = *((unsigned int *)t207);
    t243 = (t242 & t241);
    t244 = (t243 & 1U);
    if (t244 != 0)
        goto LAB80;

LAB81:    if (*((unsigned int *)t239) != 0)
        goto LAB82;

LAB83:    t246 = (t181 + 4);
    t247 = *((unsigned int *)t181);
    t248 = *((unsigned int *)t246);
    t249 = (t247 || t248);
    if (t249 > 0)
        goto LAB84;

LAB85:    t251 = *((unsigned int *)t181);
    t252 = (~(t251));
    t253 = *((unsigned int *)t246);
    t254 = (t252 || t253);
    if (t254 > 0)
        goto LAB86;

LAB87:    if (*((unsigned int *)t246) > 0)
        goto LAB88;

LAB89:    if (*((unsigned int *)t181) > 0)
        goto LAB90;

LAB91:    memcpy(t180, t255, 8);

LAB92:    goto LAB60;

LAB61:    xsi_vlog_unsigned_bit_combine(t91, 32, t175, 32, t180, 32);
    goto LAB65;

LAB63:    memcpy(t91, t175, 8);
    goto LAB65;

LAB66:    *((unsigned int *)t184) = 1;
    goto LAB69;

LAB68:    t190 = (t184 + 4);
    *((unsigned int *)t184) = 1;
    *((unsigned int *)t190) = 1;
    goto LAB69;

LAB70:    t196 = (t0 + 1208U);
    t197 = *((char **)t196);
    t196 = ((char*)((ng2)));
    memset(t198, 0, 8);
    xsi_vlog_signed_less(t198, 32, t197, 32, t196, 32);
    memset(t199, 0, 8);
    t200 = (t198 + 4);
    t201 = *((unsigned int *)t200);
    t202 = (~(t201));
    t203 = *((unsigned int *)t198);
    t204 = (t203 & t202);
    t205 = (t204 & 1U);
    if (t205 != 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t200) != 0)
        goto LAB75;

LAB76:    t208 = *((unsigned int *)t184);
    t209 = *((unsigned int *)t199);
    t210 = (t208 & t209);
    *((unsigned int *)t207) = t210;
    t211 = (t184 + 4);
    t212 = (t199 + 4);
    t213 = (t207 + 4);
    t214 = *((unsigned int *)t211);
    t215 = *((unsigned int *)t212);
    t216 = (t214 | t215);
    *((unsigned int *)t213) = t216;
    t217 = *((unsigned int *)t213);
    t218 = (t217 != 0);
    if (t218 == 1)
        goto LAB77;

LAB78:
LAB79:    goto LAB72;

LAB73:    *((unsigned int *)t199) = 1;
    goto LAB76;

LAB75:    t206 = (t199 + 4);
    *((unsigned int *)t199) = 1;
    *((unsigned int *)t206) = 1;
    goto LAB76;

LAB77:    t219 = *((unsigned int *)t207);
    t220 = *((unsigned int *)t213);
    *((unsigned int *)t207) = (t219 | t220);
    t221 = (t184 + 4);
    t222 = (t199 + 4);
    t223 = *((unsigned int *)t184);
    t224 = (~(t223));
    t225 = *((unsigned int *)t221);
    t226 = (~(t225));
    t227 = *((unsigned int *)t199);
    t228 = (~(t227));
    t229 = *((unsigned int *)t222);
    t230 = (~(t229));
    t231 = (t224 & t226);
    t232 = (t228 & t230);
    t233 = (~(t231));
    t234 = (~(t232));
    t235 = *((unsigned int *)t213);
    *((unsigned int *)t213) = (t235 & t233);
    t236 = *((unsigned int *)t213);
    *((unsigned int *)t213) = (t236 & t234);
    t237 = *((unsigned int *)t207);
    *((unsigned int *)t207) = (t237 & t233);
    t238 = *((unsigned int *)t207);
    *((unsigned int *)t207) = (t238 & t234);
    goto LAB79;

LAB80:    *((unsigned int *)t181) = 1;
    goto LAB83;

LAB82:    t245 = (t181 + 4);
    *((unsigned int *)t181) = 1;
    *((unsigned int *)t245) = 1;
    goto LAB83;

LAB84:    t250 = ((char*)((ng1)));
    goto LAB85;

LAB86:    t257 = (t0 + 2168U);
    t258 = *((char **)t257);
    memset(t259, 0, 8);
    t257 = (t258 + 4);
    t260 = *((unsigned int *)t257);
    t261 = (~(t260));
    t262 = *((unsigned int *)t258);
    t263 = (t262 & t261);
    t264 = (t263 & 1U);
    if (t264 != 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t257) != 0)
        goto LAB95;

LAB96:    t266 = (t259 + 4);
    t267 = *((unsigned int *)t259);
    t268 = *((unsigned int *)t266);
    t269 = (t267 || t268);
    if (t269 > 0)
        goto LAB97;

LAB98:    memcpy(t282, t259, 8);

LAB99:    memset(t256, 0, 8);
    t314 = (t282 + 4);
    t315 = *((unsigned int *)t314);
    t316 = (~(t315));
    t317 = *((unsigned int *)t282);
    t318 = (t317 & t316);
    t319 = (t318 & 1U);
    if (t319 != 0)
        goto LAB107;

LAB108:    if (*((unsigned int *)t314) != 0)
        goto LAB109;

LAB110:    t321 = (t256 + 4);
    t322 = *((unsigned int *)t256);
    t323 = *((unsigned int *)t321);
    t324 = (t322 || t323);
    if (t324 > 0)
        goto LAB111;

LAB112:    t326 = *((unsigned int *)t256);
    t327 = (~(t326));
    t328 = *((unsigned int *)t321);
    t329 = (t327 || t328);
    if (t329 > 0)
        goto LAB113;

LAB114:    if (*((unsigned int *)t321) > 0)
        goto LAB115;

LAB116:    if (*((unsigned int *)t256) > 0)
        goto LAB117;

LAB118:    memcpy(t255, t330, 8);

LAB119:    goto LAB87;

LAB88:    xsi_vlog_unsigned_bit_combine(t180, 32, t250, 32, t255, 32);
    goto LAB92;

LAB90:    memcpy(t180, t250, 8);
    goto LAB92;

LAB93:    *((unsigned int *)t259) = 1;
    goto LAB96;

LAB95:    t265 = (t259 + 4);
    *((unsigned int *)t259) = 1;
    *((unsigned int *)t265) = 1;
    goto LAB96;

LAB97:    t271 = (t0 + 1208U);
    t272 = *((char **)t271);
    t271 = ((char*)((ng2)));
    memset(t273, 0, 8);
    xsi_vlog_signed_leq(t273, 32, t272, 32, t271, 32);
    memset(t274, 0, 8);
    t275 = (t273 + 4);
    t276 = *((unsigned int *)t275);
    t277 = (~(t276));
    t278 = *((unsigned int *)t273);
    t279 = (t278 & t277);
    t280 = (t279 & 1U);
    if (t280 != 0)
        goto LAB100;

LAB101:    if (*((unsigned int *)t275) != 0)
        goto LAB102;

LAB103:    t283 = *((unsigned int *)t259);
    t284 = *((unsigned int *)t274);
    t285 = (t283 & t284);
    *((unsigned int *)t282) = t285;
    t286 = (t259 + 4);
    t287 = (t274 + 4);
    t288 = (t282 + 4);
    t289 = *((unsigned int *)t286);
    t290 = *((unsigned int *)t287);
    t291 = (t289 | t290);
    *((unsigned int *)t288) = t291;
    t292 = *((unsigned int *)t288);
    t293 = (t292 != 0);
    if (t293 == 1)
        goto LAB104;

LAB105:
LAB106:    goto LAB99;

LAB100:    *((unsigned int *)t274) = 1;
    goto LAB103;

LAB102:    t281 = (t274 + 4);
    *((unsigned int *)t274) = 1;
    *((unsigned int *)t281) = 1;
    goto LAB103;

LAB104:    t294 = *((unsigned int *)t282);
    t295 = *((unsigned int *)t288);
    *((unsigned int *)t282) = (t294 | t295);
    t296 = (t259 + 4);
    t297 = (t274 + 4);
    t298 = *((unsigned int *)t259);
    t299 = (~(t298));
    t300 = *((unsigned int *)t296);
    t301 = (~(t300));
    t302 = *((unsigned int *)t274);
    t303 = (~(t302));
    t304 = *((unsigned int *)t297);
    t305 = (~(t304));
    t306 = (t299 & t301);
    t307 = (t303 & t305);
    t308 = (~(t306));
    t309 = (~(t307));
    t310 = *((unsigned int *)t288);
    *((unsigned int *)t288) = (t310 & t308);
    t311 = *((unsigned int *)t288);
    *((unsigned int *)t288) = (t311 & t309);
    t312 = *((unsigned int *)t282);
    *((unsigned int *)t282) = (t312 & t308);
    t313 = *((unsigned int *)t282);
    *((unsigned int *)t282) = (t313 & t309);
    goto LAB106;

LAB107:    *((unsigned int *)t256) = 1;
    goto LAB110;

LAB109:    t320 = (t256 + 4);
    *((unsigned int *)t256) = 1;
    *((unsigned int *)t320) = 1;
    goto LAB110;

LAB111:    t325 = ((char*)((ng1)));
    goto LAB112;

LAB113:    t332 = (t0 + 2328U);
    t333 = *((char **)t332);
    memset(t334, 0, 8);
    t332 = (t333 + 4);
    t335 = *((unsigned int *)t332);
    t336 = (~(t335));
    t337 = *((unsigned int *)t333);
    t338 = (t337 & t336);
    t339 = (t338 & 1U);
    if (t339 != 0)
        goto LAB120;

LAB121:    if (*((unsigned int *)t332) != 0)
        goto LAB122;

LAB123:    t341 = (t334 + 4);
    t342 = *((unsigned int *)t334);
    t343 = *((unsigned int *)t341);
    t344 = (t342 || t343);
    if (t344 > 0)
        goto LAB124;

LAB125:    memcpy(t357, t334, 8);

LAB126:    memset(t331, 0, 8);
    t389 = (t357 + 4);
    t390 = *((unsigned int *)t389);
    t391 = (~(t390));
    t392 = *((unsigned int *)t357);
    t393 = (t392 & t391);
    t394 = (t393 & 1U);
    if (t394 != 0)
        goto LAB134;

LAB135:    if (*((unsigned int *)t389) != 0)
        goto LAB136;

LAB137:    t396 = (t331 + 4);
    t397 = *((unsigned int *)t331);
    t398 = *((unsigned int *)t396);
    t399 = (t397 || t398);
    if (t399 > 0)
        goto LAB138;

LAB139:    t401 = *((unsigned int *)t331);
    t402 = (~(t401));
    t403 = *((unsigned int *)t396);
    t404 = (t402 || t403);
    if (t404 > 0)
        goto LAB140;

LAB141:    if (*((unsigned int *)t396) > 0)
        goto LAB142;

LAB143:    if (*((unsigned int *)t331) > 0)
        goto LAB144;

LAB145:    memcpy(t330, t405, 8);

LAB146:    goto LAB114;

LAB115:    xsi_vlog_unsigned_bit_combine(t255, 32, t325, 32, t330, 32);
    goto LAB119;

LAB117:    memcpy(t255, t325, 8);
    goto LAB119;

LAB120:    *((unsigned int *)t334) = 1;
    goto LAB123;

LAB122:    t340 = (t334 + 4);
    *((unsigned int *)t334) = 1;
    *((unsigned int *)t340) = 1;
    goto LAB123;

LAB124:    t346 = (t0 + 1208U);
    t347 = *((char **)t346);
    t346 = ((char*)((ng2)));
    memset(t348, 0, 8);
    xsi_vlog_signed_greater(t348, 32, t347, 32, t346, 32);
    memset(t349, 0, 8);
    t350 = (t348 + 4);
    t351 = *((unsigned int *)t350);
    t352 = (~(t351));
    t353 = *((unsigned int *)t348);
    t354 = (t353 & t352);
    t355 = (t354 & 1U);
    if (t355 != 0)
        goto LAB127;

LAB128:    if (*((unsigned int *)t350) != 0)
        goto LAB129;

LAB130:    t358 = *((unsigned int *)t334);
    t359 = *((unsigned int *)t349);
    t360 = (t358 & t359);
    *((unsigned int *)t357) = t360;
    t361 = (t334 + 4);
    t362 = (t349 + 4);
    t363 = (t357 + 4);
    t364 = *((unsigned int *)t361);
    t365 = *((unsigned int *)t362);
    t366 = (t364 | t365);
    *((unsigned int *)t363) = t366;
    t367 = *((unsigned int *)t363);
    t368 = (t367 != 0);
    if (t368 == 1)
        goto LAB131;

LAB132:
LAB133:    goto LAB126;

LAB127:    *((unsigned int *)t349) = 1;
    goto LAB130;

LAB129:    t356 = (t349 + 4);
    *((unsigned int *)t349) = 1;
    *((unsigned int *)t356) = 1;
    goto LAB130;

LAB131:    t369 = *((unsigned int *)t357);
    t370 = *((unsigned int *)t363);
    *((unsigned int *)t357) = (t369 | t370);
    t371 = (t334 + 4);
    t372 = (t349 + 4);
    t373 = *((unsigned int *)t334);
    t374 = (~(t373));
    t375 = *((unsigned int *)t371);
    t376 = (~(t375));
    t377 = *((unsigned int *)t349);
    t378 = (~(t377));
    t379 = *((unsigned int *)t372);
    t380 = (~(t379));
    t381 = (t374 & t376);
    t382 = (t378 & t380);
    t383 = (~(t381));
    t384 = (~(t382));
    t385 = *((unsigned int *)t363);
    *((unsigned int *)t363) = (t385 & t383);
    t386 = *((unsigned int *)t363);
    *((unsigned int *)t363) = (t386 & t384);
    t387 = *((unsigned int *)t357);
    *((unsigned int *)t357) = (t387 & t383);
    t388 = *((unsigned int *)t357);
    *((unsigned int *)t357) = (t388 & t384);
    goto LAB133;

LAB134:    *((unsigned int *)t331) = 1;
    goto LAB137;

LAB136:    t395 = (t331 + 4);
    *((unsigned int *)t331) = 1;
    *((unsigned int *)t395) = 1;
    goto LAB137;

LAB138:    t400 = ((char*)((ng1)));
    goto LAB139;

LAB140:    t407 = (t0 + 2488U);
    t408 = *((char **)t407);
    memset(t409, 0, 8);
    t407 = (t408 + 4);
    t410 = *((unsigned int *)t407);
    t411 = (~(t410));
    t412 = *((unsigned int *)t408);
    t413 = (t412 & t411);
    t414 = (t413 & 1U);
    if (t414 != 0)
        goto LAB147;

LAB148:    if (*((unsigned int *)t407) != 0)
        goto LAB149;

LAB150:    t416 = (t409 + 4);
    t417 = *((unsigned int *)t409);
    t418 = *((unsigned int *)t416);
    t419 = (t417 || t418);
    if (t419 > 0)
        goto LAB151;

LAB152:    memcpy(t432, t409, 8);

LAB153:    memset(t406, 0, 8);
    t464 = (t432 + 4);
    t465 = *((unsigned int *)t464);
    t466 = (~(t465));
    t467 = *((unsigned int *)t432);
    t468 = (t467 & t466);
    t469 = (t468 & 1U);
    if (t469 != 0)
        goto LAB161;

LAB162:    if (*((unsigned int *)t464) != 0)
        goto LAB163;

LAB164:    t471 = (t406 + 4);
    t472 = *((unsigned int *)t406);
    t473 = *((unsigned int *)t471);
    t474 = (t472 || t473);
    if (t474 > 0)
        goto LAB165;

LAB166:    t476 = *((unsigned int *)t406);
    t477 = (~(t476));
    t478 = *((unsigned int *)t471);
    t479 = (t477 || t478);
    if (t479 > 0)
        goto LAB167;

LAB168:    if (*((unsigned int *)t471) > 0)
        goto LAB169;

LAB170:    if (*((unsigned int *)t406) > 0)
        goto LAB171;

LAB172:    memcpy(t405, t480, 8);

LAB173:    goto LAB141;

LAB142:    xsi_vlog_unsigned_bit_combine(t330, 32, t400, 32, t405, 32);
    goto LAB146;

LAB144:    memcpy(t330, t400, 8);
    goto LAB146;

LAB147:    *((unsigned int *)t409) = 1;
    goto LAB150;

LAB149:    t415 = (t409 + 4);
    *((unsigned int *)t409) = 1;
    *((unsigned int *)t415) = 1;
    goto LAB150;

LAB151:    t421 = (t0 + 1208U);
    t422 = *((char **)t421);
    t421 = ((char*)((ng2)));
    memset(t423, 0, 8);
    xsi_vlog_signed_greatereq(t423, 32, t422, 32, t421, 32);
    memset(t424, 0, 8);
    t425 = (t423 + 4);
    t426 = *((unsigned int *)t425);
    t427 = (~(t426));
    t428 = *((unsigned int *)t423);
    t429 = (t428 & t427);
    t430 = (t429 & 1U);
    if (t430 != 0)
        goto LAB154;

LAB155:    if (*((unsigned int *)t425) != 0)
        goto LAB156;

LAB157:    t433 = *((unsigned int *)t409);
    t434 = *((unsigned int *)t424);
    t435 = (t433 & t434);
    *((unsigned int *)t432) = t435;
    t436 = (t409 + 4);
    t437 = (t424 + 4);
    t438 = (t432 + 4);
    t439 = *((unsigned int *)t436);
    t440 = *((unsigned int *)t437);
    t441 = (t439 | t440);
    *((unsigned int *)t438) = t441;
    t442 = *((unsigned int *)t438);
    t443 = (t442 != 0);
    if (t443 == 1)
        goto LAB158;

LAB159:
LAB160:    goto LAB153;

LAB154:    *((unsigned int *)t424) = 1;
    goto LAB157;

LAB156:    t431 = (t424 + 4);
    *((unsigned int *)t424) = 1;
    *((unsigned int *)t431) = 1;
    goto LAB157;

LAB158:    t444 = *((unsigned int *)t432);
    t445 = *((unsigned int *)t438);
    *((unsigned int *)t432) = (t444 | t445);
    t446 = (t409 + 4);
    t447 = (t424 + 4);
    t448 = *((unsigned int *)t409);
    t449 = (~(t448));
    t450 = *((unsigned int *)t446);
    t451 = (~(t450));
    t452 = *((unsigned int *)t424);
    t453 = (~(t452));
    t454 = *((unsigned int *)t447);
    t455 = (~(t454));
    t456 = (t449 & t451);
    t457 = (t453 & t455);
    t458 = (~(t456));
    t459 = (~(t457));
    t460 = *((unsigned int *)t438);
    *((unsigned int *)t438) = (t460 & t458);
    t461 = *((unsigned int *)t438);
    *((unsigned int *)t438) = (t461 & t459);
    t462 = *((unsigned int *)t432);
    *((unsigned int *)t432) = (t462 & t458);
    t463 = *((unsigned int *)t432);
    *((unsigned int *)t432) = (t463 & t459);
    goto LAB160;

LAB161:    *((unsigned int *)t406) = 1;
    goto LAB164;

LAB163:    t470 = (t406 + 4);
    *((unsigned int *)t406) = 1;
    *((unsigned int *)t470) = 1;
    goto LAB164;

LAB165:    t475 = ((char*)((ng1)));
    goto LAB166;

LAB167:    t480 = ((char*)((ng2)));
    goto LAB168;

LAB169:    xsi_vlog_unsigned_bit_combine(t405, 32, t475, 32, t480, 32);
    goto LAB173;

LAB171:    memcpy(t405, t475, 8);
    goto LAB173;

}


extern void work_m_00000000003801814800_1579609468_init()
{
	static char *pe[] = {(void *)Cont_88_0};
	xsi_register_didat("work_m_00000000003801814800_1579609468", "isim/tb_mips_isim_beh.exe.sim/work/m_00000000003801814800_1579609468.didat");
	xsi_register_executes(pe);
}
