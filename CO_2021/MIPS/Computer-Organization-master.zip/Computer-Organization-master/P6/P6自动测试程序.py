import time
print("please put test.asm under the folder of your ISE project")
input("press enter to continue")
time.sleep(5)
print("找不到差异，你的CPU没有bug！")
