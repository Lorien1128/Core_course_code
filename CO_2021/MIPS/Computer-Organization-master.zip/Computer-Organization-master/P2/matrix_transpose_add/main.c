#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,m;
    int i,j;
    int a[8][8],b[8][8],c[8][8];
    scanf("%d %d",&n,&m);
    for (i=0;i<n;i++)
        for (j=0;j<m;j++)
            scanf("%d",&a[i][j]);
    for (i=0;i<n;i++)
        for (j=0;j<m;j++)
            scanf("%d",&b[i][j]);
    for (i=0;i<n;i++)
        for (j=0;j<m;j++)
            c[i][j]=a[j][i]+b[j][i];
    for (i=0;i<n-1;i++)
        {
            for (j=0;j<m-1;j++)
                printf("%d ",c[i][j]);
            printf("%d\n",c[i][m-1]);
        }
    for (j=0;j<m-1;j++)
            printf("%d ",c[n-1][j]);
    printf("%d",c[n-1][m-1]);

}
